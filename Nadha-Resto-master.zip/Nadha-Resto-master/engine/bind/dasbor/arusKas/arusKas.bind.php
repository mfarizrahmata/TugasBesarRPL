<div id='divArusKas'>
    <table id='tblArusKas' class='table table-hover'>
        <thead>
            <tr>
                <th>Kd Transaksi</th>
                <th>Waktu</th>
                <th>Tipe</th>
                <th>Arus</th>
                <th>Total</th>
                <th></th>
            </tr>
        </thead>
    </table>
</div>

<script src="<?= STYLEBASE; ?>/dasbor/arusKas.js"></script>