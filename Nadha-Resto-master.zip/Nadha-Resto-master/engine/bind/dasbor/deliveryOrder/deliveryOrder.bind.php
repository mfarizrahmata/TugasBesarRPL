<div id="divDeliveryOrder">

    <div class="row" style="padding-left:20px;margin-right:10px;">

        <table id='tblDeliveryOrder' class='table hover table-bordered table-stripped'>
            <thead>
                <tr>
                    <th>Pesanan</th>
                    <th>Status</th>
                    <th>Waktu</th>
                    <th>Kurir</th>
                    <th>Total Harga</th>
                    <th></th>
                </tr>
            </thead>
        </table>

    </div>

</div>

<script src="<?=STYLEBASE; ?>/dasbor/deliveryOrder.js"></script>