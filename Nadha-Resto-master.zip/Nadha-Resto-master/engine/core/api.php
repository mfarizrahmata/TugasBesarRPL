<?php
 
 $apiAdress = 'http//:api.haxors.or.id';