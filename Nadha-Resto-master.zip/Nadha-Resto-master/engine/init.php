<?php
/**
* Init file
* Call the functional file core & rule
* singkronkan
*/
require_once 'core/props.php';
require_once 'core/route.php';
require_once 'core/state.php';
require_once 'rule/base.php';
require_once 'rule/database.php';
