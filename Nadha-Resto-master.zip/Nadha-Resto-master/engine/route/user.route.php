<?php

class user extends Route{

    private $sn = 'userData';
    private $su = 'utilityData';

    public function index()
    {
        echo "<pre>Meaowww...</pre>";
    }

}