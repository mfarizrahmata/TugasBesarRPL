<?php 

class bantuanData{
   
    private $st;

    public function __construct()
    {
        $this -> st = new state;
    }

}