// ROUTE 
var routeToGetBantuan = '';