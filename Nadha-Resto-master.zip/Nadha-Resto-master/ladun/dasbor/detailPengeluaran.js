$('#btnShow').click(function(){
    console.log("data");
});