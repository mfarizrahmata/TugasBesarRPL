export const $body = $('body')
export const $bodyOverlay = $('#body-overlay')
export const $headerMobile = $('#header-mobile')
export const $footer = $('#footer')

export const currency = '$'
